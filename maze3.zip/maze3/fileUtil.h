#include <stdio.h>
#include <stdlib.h>
#include<string.h>

#include "Debug.h"

struct Conf{
	float SPEEDSCALE;	//最高速的比例0-1
	unsigned char DIS_LEFT;		//当前超声波探测器测量的距离大于DIS_LEFT，表左方有路,单位CM
	unsigned char DIS_COLLIDE_MIN;	//左贴墙最小距离
	unsigned char DIS_COLLIDE_MAX;	//左贴墙最大距离
	unsigned char DIS_COLLIDE_FRONT;//前进规避碰撞距离
	float ANGLEPERMT; //偏转每度所需毫秒值
};

int readConfFile(struct Conf* CONF);
int writeConfFile(struct Conf* CONF);
void printConf(struct Conf CONF);

int praseConfStr(char* str,struct Conf* CONF);
