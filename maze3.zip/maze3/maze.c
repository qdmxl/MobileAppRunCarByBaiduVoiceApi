#include "carOpt.h"


struct Conf CONF={0,0,0,0,0,0};
//				 0.8,30,5,10,10,8.9

int main(int argc, char* argv[])
{
	if(argc==2){
		praseConfStr(argv[1],&CONF);
		if(writeConfFile(&CONF))
			PLOG("writeConfFile OK!\n");
	}else if(argc==1||CONF.SPEEDSCALE==0){
		if(readConfFile(&CONF))
			PLOG("readConfFile OK!\n");
	}
	printConf(CONF);
	
	float frontDis,leftDis,rightDis,saveLeftDis;
	unsigned char frontPath;

    wiringPiSetup();
	ultraInit();
    /*WiringPi GPIO*/
    pinMode(1, OUTPUT);  //IN1
    pinMode(4, OUTPUT);  //IN2
    pinMode(5, OUTPUT);  //IN3
    pinMode(6, OUTPUT);  //IN4
    softPwmCreate(1, 1, 100);
    softPwmCreate(4, 1, 100);
    softPwmCreate(5, 1, 100);
    softPwmCreate(6, 1, 100);
	
	while(1){
		leftDis=disMeasure(Trig1,Echo1);
		PLOG("leftDis = %0.2f cm\n", leftDis);
		if(leftDis>=CONF.DIS_LEFT){//左边有路
			PLOG("#############goLeft#############\n");
			goLeft(saveLeftDis);//进入左道
		}else
			saveLeftDis=leftDis;
		goLeftWall(leftDis);
				
		frontDis=disMeasure(Trig,Echo);
		frontPath=frontDis>=CONF.DIS_COLLIDE_FRONT;
		PLOG("frontDis = %0.2f cm :frontPath=%d\n", frontDis,frontPath);
		if(frontPath){				
			PLOG("#############run#############\n");
			run();//前进
			delay(100);
			continue;
		}
		else{
			rightDis=disMeasure(Trig2,Echo2);
			PLOG("#############goRight###### rightDis = %0.2f cm\n",rightDis);
			rightAngle(90+5);//进入右道
		}
	}
	return 0;
}
