#include "fileUtil.h"

int readConfFile(struct Conf* CONF){
	FILE* fp;
	
	if(!CONF)
		return 0;
	fp=fopen("./Setting.conf","r");
	if(!fp)
	{
		PLOG("wirte pathfile error\n");
		return 0;
	}
	
	fscanf(fp,"SPEEDSCALE=%f\n",&CONF->SPEEDSCALE);
	fscanf(fp,"DIS_LEFT=%d\n",&CONF->DIS_LEFT);
	fscanf(fp,"DIS_COLLIDE_MIN=%d\n",&CONF->DIS_COLLIDE_MIN);
	fscanf(fp,"DIS_COLLIDE_MAX=%d\n",&CONF->DIS_COLLIDE_MAX);
	fscanf(fp,"DIS_COLLIDE_FRONT=%d\n",&CONF->DIS_COLLIDE_FRONT);
	fscanf(fp,"ANGLEPERMT=%f\n",&CONF->ANGLEPERMT);
	
	fclose(fp);
	return 1;
}

int writeConfFile(struct Conf* CONF){
	FILE* fp;
	
	if(!CONF)
		return 0;
	fp=fopen("./Setting.conf","w+");
	if(!fp)
	{
		PLOG("wirte pathfile error\n");
		return 0;
	}

	fprintf(fp,"SPEEDSCALE=%f\n",CONF->SPEEDSCALE);
	fprintf(fp,"DIS_LEFT=%d\n",CONF->DIS_LEFT);
	fprintf(fp,"DIS_COLLIDE_MIN=%d\n",CONF->DIS_COLLIDE_MIN);
	fprintf(fp,"DIS_COLLIDE_MAX=%d\n",CONF->DIS_COLLIDE_MAX);
	fprintf(fp,"DIS_COLLIDE_FRONT=%d\n",CONF->DIS_COLLIDE_FRONT);
	fprintf(fp,"ANGLEPERMT=%f\n",CONF->ANGLEPERMT);
	
	fclose(fp);
	return 1;
}


void printConf(struct Conf CONF){
	printf("SPEEDSCALE=%f,DIS_LEFT=%d,DIS_COLLIDE_MIN=%d,DIS_COLLIDE_MAX=%d,DIS_COLLIDE_FRONT=%d,ANGLEPERMT=%f\n",CONF.SPEEDSCALE,CONF.DIS_LEFT,CONF.DIS_COLLIDE_MIN,CONF.DIS_COLLIDE_MAX,CONF.DIS_COLLIDE_FRONT,CONF.ANGLEPERMT);
}

//str:"0.5,30,5,10,10,3,8.9" len:
int praseConfStr(char* str,struct Conf* CONF){
	if(!str||!CONF)
		return 0;
	unsigned int no=0;
	char* delim=",";//分隔符字符串
    char* p=strtok(str,delim);//第一次调用strtok
    while(p!=NULL){//当返回值不为NULL时，继续循环
        //printf("%s\n",p);//输出分解的字符串
		switch(no){
			case 0:CONF->SPEEDSCALE=(float)atof(p);break;
			case 1:CONF->DIS_LEFT=(unsigned char)atoi(p);break;
			case 2:CONF->DIS_COLLIDE_MIN=(unsigned char)atoi(p);break;
			case 3:CONF->DIS_COLLIDE_MAX=(unsigned char)atoi(p);break;
			case 4:CONF->DIS_COLLIDE_FRONT=(unsigned char)atoi(p);break;
			case 5:CONF->ANGLEPERMT=(float)atof(p);break;
			default:break;
		}
        p=strtok(NULL,delim);//继续调用strtok，分解剩下的字符串
		no++;
    }
	return 1;
}
