#include <stdio.h>
#include <stdlib.h>
#include <softPwm.h>
#include <time.h>
#include <wiringPi.h>

#include "fileUtil.h"

#define Trig  28//前超声波
#define Echo  29
#define Trig1 24//左超声波
#define Echo1 25
#define Trig2 21//右超声波
#define Echo2 22

#define CARLENGTH 25	//车身长25CM
#define CARWIDTH 16		//车身宽16CM

extern struct Conf CONF;
float SPEED=25;

void ultraInit(void)
{
    pinMode(Echo, INPUT);
    pinMode(Trig, OUTPUT);
	pinMode(Echo1, INPUT);
    pinMode(Trig1, OUTPUT);
	pinMode(Echo2, INPUT);
    pinMode(Trig2, OUTPUT);
	SPEED=40*CONF.SPEEDSCALE;
}

float disMeasure(int trig,int echo)
{
	//struct timeval {
	//	time_t tv_sec;	//64位系统下的time_t类型即long类型长度为8个字节
	//	suseconds_t tv_usec;
	//;
    struct timeval tv1,tv2;
    long start, stop;
    float dis;
    digitalWrite(trig, LOW);
    delayMicroseconds(2);
    digitalWrite(trig, HIGH);
    delayMicroseconds(10); //发出超声波脉冲
    digitalWrite(trig, LOW);
    while(!(digitalRead(echo) == 1));
    gettimeofday(&tv1, NULL); //获取当前时间
    while(!(digitalRead(echo) == 0));
    gettimeofday(&tv2, NULL); //获取当前时间
    start = tv1.tv_sec * 1000000 + tv1.tv_usec; //微秒级的时间 
    stop = tv2.tv_sec * 1000000 + tv2.tv_usec;
    dis = (float)(stop - start) / 1000000 * 34000 / 2; //求出距离
    return dis;
}


void brake(int time) //刹车，停车 time ms
{
    softPwmWrite(1, 0);
    softPwmWrite(4, 0);
    softPwmWrite(5, 0);
    softPwmWrite(6, 0);
    delay(time);//执行时间，可以调整
}


void run() // 前进
{
	softPwmWrite(1, 100*CONF.SPEEDSCALE); //左轮前进
    softPwmWrite(4, 0);
	softPwmWrite(5, 100*CONF.SPEEDSCALE); //右轮前进
    softPwmWrite(6, 0);
}

//length	cm
//curSpeed	cm/s 为正值
void runLength(float length,float curSpeed){
	float tempSpeed=curSpeed;
	float endTime=0;
	float frontDis=0;
	
	endTime=length*1000/tempSpeed+millis();//millis() wiringPiSetup开始后的ms

	while(1){
		run();
		frontDis=disMeasure(Trig,Echo);
		delay(50);
		if(millis()>=endTime||frontDis<CONF.DIS_COLLIDE_FRONT){
			brake(10);
			break;
		}
			
	}
}


void left(int time) //左转（左轮后退，右轮前进）
{
    softPwmWrite(1, 0);
    softPwmWrite(4, 100*CONF.SPEEDSCALE);//左轮后退
    softPwmWrite(5, 100*CONF.SPEEDSCALE);//右轮前进
    softPwmWrite(6, 0); 
    delay(time);
}

void leftAngle(unsigned char angle){
	int angleToTime = (int)CONF.ANGLEPERMT*angle;
	brake(200);
	left(angleToTime);
	brake(10);
}

void goLeft(float leftDis){
	//runLength(leftDis/2,SPEED);
	//leftAngle(90);
	//runLength(leftDis,SPEED);
	runLength(leftDis,SPEED);
	leftAngle(90);
	runLength(leftDis*1.4,SPEED);
}

void right(int time) //右转(右轮后退，左轮前进)
{
    softPwmWrite(1, 100*CONF.SPEEDSCALE);//左轮前进
    softPwmWrite(4, 0); 
    softPwmWrite(5, 0);
    softPwmWrite(6, 100*CONF.SPEEDSCALE);
    delay(time); //执行时间，可以调整
}

void rightAngle(unsigned char angle){
	int angleToTime = (int)CONF.ANGLEPERMT*angle;
	brake(200);
	right(angleToTime);
	brake(10);
}


void goLeftWall(float leftDis){
	int angleToTime=0;
	unsigned char leftFlag=leftDis>CONF.DIS_COLLIDE_MIN;
	unsigned char leftFlag2=leftDis<CONF.DIS_COLLIDE_MAX;
	if(!leftFlag){
		angleToTime = (int)CONF.ANGLEPERMT*3;
		//brake(100);
		PLOG(">>>>>>>>>GO Right\n");
		softPwmWrite(1, 100*CONF.SPEEDSCALE);//左轮前进
		softPwmWrite(4, 0); 
		softPwmWrite(5, 0);
		softPwmWrite(6, 100*CONF.SPEEDSCALE);//右轮后退
		delay(angleToTime);
	}
	if(!leftFlag2){
		angleToTime = (int)CONF.ANGLEPERMT*3;
		//brake(100);
		PLOG("<<<<<<<<<GO Left\n");
		softPwmWrite(1, 0);
		softPwmWrite(4, 100*CONF.SPEEDSCALE);//左轮后退
		softPwmWrite(5, 100*CONF.SPEEDSCALE);//右轮前进
		softPwmWrite(6, 0);
		delay(angleToTime);
	}
}


