package com.carclienta;

import android.Manifest;
import android.content.SharedPreferences;
import android.content.pm.PackageManager;
import android.os.Bundle;
import android.os.Handler;
import android.os.Message;
import android.preference.PreferenceManager;
import android.support.v4.app.ActivityCompat;
import android.support.v4.app.Fragment;
import android.support.v4.content.ContextCompat;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import com.baidu.aip.asrwakeup3.core.mini.AutoCheck;
import com.baidu.aip.asrwakeup3.core.recog.IStatus;
import com.baidu.aip.asrwakeup3.core.recog.MyRecognizer;
import com.baidu.aip.asrwakeup3.core.recog.listener.IRecogListener;
import com.baidu.aip.asrwakeup3.core.recog.listener.MessageStatusRecogListener;
import com.gc.materialdesign.views.ButtonRectangle;

import java.io.OutputStream;
import java.net.Socket;
import java.util.ArrayList;
import java.util.Map;
import java.util.Timer;
import java.util.TimerTask;
import java.util.concurrent.ExecutorService;


public class FragmentSoundOpt extends Fragment {
    View view;
    TextView tv_sound;
    private ButtonRectangle bt_start;
    private ButtonRectangle bt_end;


    // 输出流对象
    OutputStream outputStream;
    Socket socket;
    ExecutorService mThreadPool;

    /**
     * 识别控制器，使用MyRecognizer控制识别的流程
     */
    protected MyRecognizer myRecognizer;
    /*
     * 本Activity中是否需要调用离线命令词功能。根据此参数，判断是否需要调用SDK的ASR_KWS_LOAD_ENGINE事件
     */
    protected boolean enableOffline=true;
    protected Handler handler;
    Map<String, Object> offlineParams;
    SimpleRecogListener listener;
    boolean usingflag=false;
    String allComdStr="";

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        view = inflater.inflate(R.layout.fragment_soundopt, container, false);
        initView();
        return view;
    }

    @Override
    public void onViewCreated(View view, Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);
    }

    /**
     * 销毁时需要释放识别资源。
     * activity默认以下初始化相近的2个Fragment，不用会被销毁视图，不是销毁fragment对象
     */
    @Override
    public void onDestroyView() {
        // DEMO集成步骤3 释放资源
        // 如果之前调用过myRecognizer.loadOfflineEngine()， release()里会自动调用释放离线资源
        myRecognizer.release();
        super.onDestroyView();
    }

    private void initView() {
        tv_sound = view.findViewById(R.id.tv_sound);
        bt_start = view.findViewById(R.id.bt_Start);
        bt_end = view.findViewById(R.id.bt_End);
        bt_start.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                allComdStr="";
                tv_sound.setText(allComdStr);
                String str="3:2\n";
                sendData(str);
                usingflag=true;
                // DEMO集成步骤2.2 开始识别
                myRecognizer.start(offlineParams);
            }
        });

        bt_end.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String str="3:3\n";
                sendData(str);
                usingflag=false;
                myRecognizer.stop();
            }
        });
        intitBaiDuRecog();
    }

    private void intitBaiDuRecog() {
        handler = new Handler() {
            @Override
            public void handleMessage(Message msg) {
                super.handleMessage(msg);
                if (tv_sound != null && msg.obj != null) {
                    switch (msg.arg1){
                        case IStatus.STATUS_NONE:
                            tv_sound.setText(allComdStr);
                            if(usingflag){
                                // DEMO集成步骤2.2 开始识别
                                myRecognizer.start(offlineParams);break;
                            }
                        case IStatus.STATUS_FINISHED:
                            String str="3:4:";
                            if(listener.rightResult==null||listener.rightResult=="")
                                break;
                            switch (listener.rightResult){
                                case "停止":str+="0\n";break;
                                case "前进":str+="1\n";break;
                                case "前进左转":str+="2\n";break;
                                case "左转":str+="3\n";break;
                                case "后退左转":str+="4\n";break;
                                case "后退":str+="5\n";break;
                                case "后退右转":str+="6\n";break;
                                case "右转":str+="7\n";break;
                                case "前进右转":str+="8\n";break;
                                default:str+="0\n";break;
                            }
                            allComdStr+=listener.rightResult+"\n";
                            listener.rightResult="";
                            System.out.println(str);
                            sendData(str);
                            tv_sound.append(msg.obj.toString() + "\n");break;
                        default:tv_sound.append(msg.obj.toString() + "\n");break;
                    }
                }
            }
        };
        initPermission();
        // DEMO集成步骤 1.1 新建一个回调类，识别引擎会回调这个类告知重要状态和识别结果
        listener = new SimpleRecogListener(handler);
        // DEMO集成步骤 1.2 初始化：new一个IRecogListener示例 & new 一个 MyRecognizer 示例
        myRecognizer = new MyRecognizer(getActivity(),listener);
        if (enableOffline) {
            // 集成步骤 1.3（可选）加载离线资源。offlineParams是固定值，复制到您的代码里即可
            offlineParams = OfflineRecogParams.fetchOfflineParams();
            myRecognizer.loadOfflineEngine(offlineParams);
        }
    }

    /**
     * android 6.0 以上需要动态申请权限
     */
    private void initPermission() {
        String[] permissions = {
                Manifest.permission.RECORD_AUDIO,
                Manifest.permission.ACCESS_NETWORK_STATE,
                Manifest.permission.INTERNET,
                Manifest.permission.READ_PHONE_STATE,
                Manifest.permission.WRITE_EXTERNAL_STORAGE
        };

        ArrayList<String> toApplyList = new ArrayList<String>();

        for (String perm : permissions) {
            if (PackageManager.PERMISSION_GRANTED != ContextCompat.checkSelfPermission(getActivity(), perm)) {
                toApplyList.add(perm);
                // 进入到这里代表没有权限.

            }
        }
        String[] tmpList = new String[toApplyList.size()];
        if (!toApplyList.isEmpty()) {
            ActivityCompat.requestPermissions(getActivity(), toApplyList.toArray(tmpList), 123);
        }

    }

    @Override
    public void onRequestPermissionsResult(int requestCode, String[] permissions, int[] grantResults) {
        // 此处为android 6.0以上动态授权的回调，用户自行实现。
    }

    void sendData(final String str){
        socket=((MainActivity)getActivity()).getSocket();
        mThreadPool=((MainActivity)getActivity()).getmThreadPool();
        mThreadPool.execute(new Runnable() {
            @Override
            public void run() {
                try {
                    // 步骤1：从Socket 获得输出流对象OutputStream
                    // 该对象作用：发送数据
                    outputStream = socket.getOutputStream();

                    // 步骤2：写入需要发送的数据到输出流对象中
                    outputStream.write(str.getBytes("utf-8"));
                    // 特别注意：数据的结尾加上换行符才可让服务器端的readline()停止阻塞

                    // 步骤3：发送数据到服务端
                    outputStream.flush();
                } catch (Exception e) {
                    e.printStackTrace();
                }
            }
        });
    }
}
