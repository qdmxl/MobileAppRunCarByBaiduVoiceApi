package com.carclienta;

import android.os.Bundle;
import android.support.v4.app.Fragment;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import java.io.IOException;
import java.io.OutputStream;
import java.net.Socket;
import java.util.concurrent.ExecutorService;


public class FragmentKeyOpt extends Fragment {
    // 输出流对象
    OutputStream outputStream;
    Socket socket;
    ExecutorService mThreadPool;

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
//        socket=((MainActivity)getActivity()).getSocket();
//        mThreadPool=((MainActivity)getActivity()).getmThreadPool();
        // Inflate the layout for this fragment
        View view=inflater.inflate(R.layout.fragment_keyopt, container, false);
        GamePad gp=view.findViewById(R.id.gp);
        gp.setOnDirectionListener(new GamePad.OnDirectionListener() {
            @Override
            public void onUp() {
                System.out.println("onUp");
                String str="2:4:1\n";
                sendData(str);
            }

            @Override
            public void onUpLeft() {
                System.out.println("onUpLeft");
                sendData("2:4:2\n");
            }

            @Override
            public void onLeft() {
                System.out.println("onLeft");
                sendData("2:4:3\n");
            }

            @Override
            public void onDownLeft() {
                System.out.println("onDownLeft");
                sendData("2:4:4\n");
            }

            @Override
            public void onDown() {
                System.out.println("onDown");
                sendData("2:4:5\n");
            }

            @Override
            public void onDownRight() {
                System.out.println("onDownRight");
                sendData("2:4:6\n");
            }

            @Override
            public void onRight() {
                System.out.println("onRight");
                sendData("2:4:7\n");
            }

            @Override
            public void onUpRight() {
                System.out.println("onUpRight");
                sendData("2:4:8\n");
            }

            @Override
            public void onLeave() {
                System.out.println("onLeave");
                sendData("2:4:0\n");
                sendData("2:4:0\n");
                sendData("2:4:0\n");
            }
        });
        return view;
    }

    @Override
    public void onViewCreated(View view, Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);
    }

    void sendData(final String str){
        socket=((MainActivity)getActivity()).getSocket();
        mThreadPool=((MainActivity)getActivity()).getmThreadPool();
        mThreadPool.execute(new Runnable() {
            @Override
            public void run() {
                try {
                    // 步骤1：从Socket 获得输出流对象OutputStream
                    // 该对象作用：发送数据
                    outputStream = socket.getOutputStream();

                    // 步骤2：写入需要发送的数据到输出流对象中
                    outputStream.write(str.getBytes("utf-8"));
                    // 特别注意：数据的结尾加上换行符才可让服务器端的readline()停止阻塞

                    // 步骤3：发送数据到服务端
                    outputStream.flush();
                } catch (Exception e) {
                    e.printStackTrace();
                }
            }
        });
    }
}
