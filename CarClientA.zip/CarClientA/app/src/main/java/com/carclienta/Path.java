package com.carclienta;

import android.util.AndroidException;

import java.util.List;

/**
 * Created by lenovo on 2018/11/2.
 */

public class Path {
    private double scale;//每像素代表的距离 cm/dp

    public Path(double scale) {
        this.scale = 0.25;
        this.scale = scale;
    }

    public String prasePath(List<FragmentPathOpt.point> lp) {
        int num = lp.size();
        int count = 0;
        String pathstr = "4:1:";
        int angle, dir = 0;
        double dis;
        FragmentPathOpt.point p1 = null, p2 = null, p3 = null, p0;
        if (num <= 1)
            return null;
        while (count <= num) {
            if (count == 0) {
                p1 = lp.get(count++);
                p2 = lp.get(count++);
                p0 = new FragmentPathOpt.point(p1.x, p1.y + 1);
                angle = getDegrees(p0.x, p0.y, p1.x, p1.y, p2.x, p2.y);
                dir = getDir(p0.x, p0.y, p1.x, p1.y, p2.x, p2.y);
                dis = getDistance(p1.x, p1.y, p2.x, p2.y);
                System.out.println("dir=" + dir + ";angle=" + angle + ";dis=" + dis);
                if (dir == 7) {
                    if(angle>0)
                        pathstr += "7=" + String.valueOf(angle) + ",";
                    pathstr += "1=" + String.valueOf((int) (dis * scale)) + ",";
                } else if (dir == 3) {
                    if(angle>0)
                        pathstr += "3=" + String.valueOf(angle) + ",";
                    pathstr += "1=" + String.valueOf((int) (dis * scale)) + ",";
                } else if (dir == 0) {
                    pathstr += "1=" + String.valueOf((int) (dis * scale)) + ",";
                }
                if (num >= 3)
                    p3 = lp.get(count++);
                else
                    break;
                continue;
            }
            angle = getDegrees(p1.x, p1.y, p2.x, p2.y, p3.x, p3.y);
            dir = getDir(p1.x, p1.y, p2.x, p2.y, p3.x, p3.y);
            dis = getDistance(p2.x, p2.y, p3.x, p3.y);
            System.out.println("dir=" + dir + ";angle=" + angle + ";dis=" + dis);
            if (dir == 7) {
                if(angle>0)
                    pathstr += "7=" + String.valueOf(angle) + ",";
                pathstr += "1=" + String.valueOf((int) (dis * scale)) + ",";
            } else if (dir == 3 ) {
                if(angle>0)
                    pathstr += "3=" + String.valueOf(angle) + ",";
                pathstr += "1=" + String.valueOf((int) (dis * scale)) + ",";
            } else if (dir == 0) {
                pathstr += "1=" + String.valueOf((int) (dis * scale)) + ",";
            }
            p1.setVal(p2.x, p2.y);
            p2.setVal(p3.x, p3.y);
            if (count < num)
                p3 = lp.get(count++);
            else
                count++;
        }
        pathstr = pathstr.substring(0, pathstr.lastIndexOf(",")) + "\n";
        return pathstr;
    }

    private int getDegrees(float firstX, float firstY, float secondX, float secondY, float thridX, float thridY) {
        double ab = (secondX - firstX) * (thridX - secondX) + (secondY - firstY) * (thridY - secondY);
        double am = Math.sqrt((secondX - firstX) * (secondX - firstX) + (secondY - firstY) * (secondY - firstY));
        double bm = Math.sqrt((secondX - thridX) * (secondX - thridX) + (secondY - thridY) * (secondY - thridY));
        double val = ab / (am * bm);
        double hd = Math.acos(val);
        return (int) (hd * 180 / Math.PI);
    }

    private int getDir(float firstX, float firstY, float secondX, float secondY, float thridX, float thridY) {
        double am = Math.sqrt((secondX - firstX) * (secondX - firstX) + (secondY - firstY) * (secondY - firstY));
        double bm = Math.sqrt((secondX - thridX) * (secondX - thridX) + (secondY - thridY) * (secondY - thridY));
        double ax = (secondX - firstX) / am;
        double ay = (secondY - firstY) / am;
        double bx = (thridX - secondX) / bm;
        double by = (thridY - secondY) / bm;
        if(ax==0){
            if(ay>0)
                if(bx<0) return 7; else return 3;
            else
                if(bx>0) return 7; else return 3;
        }
        if(ay==0){
            if(ax>0)
                if(by>0) return 7; else return 3;
            else
                if(by<0) return 7; else return 3;
        }

        if (ax > 0 && ay > 0) {
            if (bx >= 0 && by > 0)
                if (by > ay) return 7; else return 3;
            if (bx < 0 && by <= 0)
                if (by > -ay) return 7; else return 3;
            if (bx < 0 && by > 0) return 7;
            if (bx > 0 && by < 0) return 3;
        }
        if (ax < 0 && ay > 0) {
            if (bx < 0 && by >= 0)
                if (by < ay) return 7; else return 3;
            if (bx >= 0 && by < 0)
                if (by < -ay) return 7; else return 3;
            if (bx < 0 && by < 0) return 7;
            if (bx > 0 && by > 0) return 3;
        }
        if (ax < 0 && ay < 0) {
            if (bx <= 0 && by < 0)
                if (by < ay) return 7; else return 3;
            if (bx > 0 && by >= 0)
                if (by < -ay) return 7; else return 3;
            if (bx > 0 && by < 0) return 7;
            if (bx < 0 && by > 0) return 3;
        }
        if (ax > 0 && ay < 0) {
            if (bx > 0 && by <= 0)
                if (by < ay) return 7; else return 3;
            if (bx <= 0 && by > 0)
                if (by > -ay) return 7; else return 3;
            if (bx > 0 && by > 0) return 7;
            if (bx < 0 && by < 0) return 3;
        }
        if (ax == bx && ay == by)
            return 0;
        return 0;
    }

    private double getDistance(float firstX, float firstY, float secondX, float secondY) {
        return Math.sqrt(Math.pow(firstX - secondX, 2) + Math.pow(firstY - secondY, 2));
    }
}
