package com.carclienta;

import android.os.Bundle;
import android.support.v4.app.Fragment;
import android.text.TextUtils;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import com.gc.materialdesign.views.ButtonRectangle;

import java.io.OutputStream;
import java.net.Socket;
import java.util.concurrent.ExecutorService;


public class FragmentMaze extends Fragment {
    private View view;
    private EditText et_speedscale;
    private EditText et_dis_left;
    private EditText et_dis_collide_min;
    private EditText et_dis_collide_max;
    private EditText et_dis_collide_front;
    private EditText et_anglepermt;
    private ButtonRectangle bt_conf;
    private ButtonRectangle bt_start;
    private ButtonRectangle bt_end;
    // 输出流对象
    OutputStream outputStream;
    Socket socket;
    ExecutorService mThreadPool;



    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        view = inflater.inflate(R.layout.fragment_maze, container, false);
        initView();
        return view;
    }

    @Override
    public void onViewCreated(View view, Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);
    }

    private void initView() {
        et_speedscale = view.findViewById(R.id.et_SPEEDSCALE);
        et_dis_left = view.findViewById(R.id.et_DIS_LEFT);
        et_dis_collide_min = view.findViewById(R.id.et_DIS_COLLIDE_MIN);
        et_dis_collide_max = view.findViewById(R.id.et_DIS_COLLIDE_MAX);
        et_dis_collide_front = view.findViewById(R.id.et_DIS_COLLIDE_FRONT);
        et_anglepermt = view.findViewById(R.id.et_ANGLEPERMT);
        bt_conf = view.findViewById(R.id.bt_Conf);
        bt_start = view.findViewById(R.id.bt_Start);
        bt_end = view.findViewById(R.id.bt_End);

        bt_conf.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if ( TextUtils.isEmpty(et_speedscale.getText()) ||
                        TextUtils.isEmpty(et_dis_left.getText()) ||
                        TextUtils.isEmpty(et_dis_collide_min.getText()) ||
                        TextUtils.isEmpty(et_dis_collide_max.getText()) ||
                        TextUtils.isEmpty(et_dis_collide_front.getText()) ||
                        TextUtils.isEmpty(et_anglepermt.getText())) {
                    Toast.makeText(getActivity(), "请填写完整或都不要填", Toast.LENGTH_SHORT).show();
                    return;
                }
                String str = "1:1:";
                str += et_speedscale.getText().toString() + "," +
                        et_dis_left.getText().toString() + "," +
                        et_dis_collide_min.getText().toString() + "," +
                        et_dis_collide_max.getText().toString() + "," +
                        et_dis_collide_front.getText().toString() + "," +
                        et_anglepermt.getText().toString() + "\n";
                System.out.println(str);
                sendData(str);
            }
        });
        bt_start.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String str = "1:2";
                sendData(str);
            }
        });
        bt_end.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String str = "1:3";
                sendData(str);
            }
        });
    }

    void sendData(final String str) {
        socket = ((MainActivity) getActivity()).getSocket();
        mThreadPool = ((MainActivity) getActivity()).getmThreadPool();
        mThreadPool.execute(new Runnable() {
            @Override
            public void run() {
                try {
                    // 步骤1：从Socket 获得输出流对象OutputStream
                    // 该对象作用：发送数据
                    outputStream = socket.getOutputStream();

                    // 步骤2：写入需要发送的数据到输出流对象中
                    outputStream.write(str.getBytes("utf-8"));
                    // 特别注意：数据的结尾加上换行符才可让服务器端的readline()停止阻塞

                    // 步骤3：发送数据到服务端
                    outputStream.flush();
                } catch (Exception e) {
                    e.printStackTrace();
                }
            }
        });
    }
}
