package com.carclienta;

import android.content.Context;
import android.content.Intent;
import android.net.DhcpInfo;
import android.net.Uri;
import android.net.wifi.WifiManager;
import android.os.Bundle;
import android.os.Handler;
import android.support.design.widget.TabLayout;
import android.support.v4.app.Fragment;
import android.support.v4.app.FragmentManager;
import android.support.v4.app.FragmentPagerAdapter;
import android.support.v4.view.ViewPager;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.Toolbar;
import android.view.Menu;
import android.view.MenuItem;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.net.Socket;
import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

public class MainActivity extends AppCompatActivity {
    /**
     * 主 变量
     */

    // 主线程Handler
    // 用于将从服务器获取的消息显示出来
    private Handler mMainHandler;

    // Socket变量
    private Socket socket;
    public Socket getSocket() {
        return socket;
    }

    // 线程池
    // 为了方便展示,此处直接采用线程池进行线程管理,而没有一个个开线程
    private ExecutorService mThreadPool;
    public ExecutorService getmThreadPool() {
        return mThreadPool;
    }

    /**
     * 接收服务器消息 变量
     */
    // 输入流对象
    InputStream is;

    // 输入流读取器对象
    InputStreamReader isr ;
    BufferedReader br ;

    // 接收服务器发送过来的消息
    String response;
    /**
     * 发送消息到服务器 变量
     */
    // 输出流对象
    OutputStream outputStream;


    private SectionsPagerAdapter mSectionsPagerAdapter;

    private ViewPager mViewPager;
    private List<Fragment> mFragmentList=new ArrayList<Fragment>();
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        mFragmentList.add(new FragmentMaze());
        mFragmentList.add(new FragmentKeyOpt());
        mFragmentList.add(new FragmentSoundOpt());
        mFragmentList.add(new FragmentPathOpt());
        Toolbar toolbar = (Toolbar) findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);
        mSectionsPagerAdapter = new SectionsPagerAdapter(getSupportFragmentManager());
        mViewPager = (ViewPager) findViewById(R.id.container);
        mViewPager.setAdapter(mSectionsPagerAdapter);

        TabLayout tabLayout = (TabLayout) findViewById(R.id.tabs);
        tabLayout.setupWithViewPager(mViewPager);
        // 初始化线程池
        mThreadPool = Executors.newCachedThreadPool();
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        getMenuInflater().inflate(R.menu.menu_main, menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        int id = item.getItemId();

        if (id == R.id.Connnect) {
// 利用线程池直接开启一个线程 & 执行该线程
            mThreadPool.execute(new Runnable() {
                @Override
                public void run() {
                    try {
                        // 创建Socket对象 & 指定服务端的IP 及 端口号
                        socket = new Socket("192.168.12.1", 6666);
                        // 判断客户端和服务器是否连接成功
                        System.out.println(socket.isConnected());
                    } catch (IOException e) {
                        e.printStackTrace();
                    }
                }
            });
            return true;
        }else if(id==R.id.Disconnect){
            try {
                // 断开 客户端发送到服务器 的连接，即关闭输出流对象OutputStream
                //outputStream.close();
                // 断开 服务器发送到客户端 的连接，即关闭输入流读取器对象BufferedReader
                //br.close();
                // 最终关闭整个Socket连接
                socket.close();
                // 判断客户端和服务器是否已经断开连接
                System.out.println(socket.isConnected());
            } catch (IOException e) {
                e.printStackTrace();
            }
            return true;
        }

        return super.onOptionsItemSelected(item);
    }

    void sendData(final String str){
        mThreadPool.execute(new Runnable() {
            @Override
            public void run() {
                try {
                    if(socket==null)
                        return;
                    // 步骤1：从Socket 获得输出流对象OutputStream
                    // 该对象作用：发送数据
                    outputStream = socket.getOutputStream();

                    // 步骤2：写入需要发送的数据到输出流对象中
                    outputStream.write(str.getBytes("utf-8"));
                    // 特别注意：数据的结尾加上换行符才可让服务器端的readline()停止阻塞

                    // 步骤3：发送数据到服务端
                    outputStream.flush();
                } catch (IOException e) {
                    e.printStackTrace();
                }
            }
        });
    }

    public class SectionsPagerAdapter extends FragmentPagerAdapter {

        public SectionsPagerAdapter(FragmentManager fm) {
            super(fm);
        }
//        boolean keyFlag=false;

        @Override
        public Fragment getItem(int position) {
//            System.out.println("position:"+position);
//            if(!keyFlag&&position==2){
//                sendData("2:2\n");//KeyOpt开始
//                keyFlag=true;
//            }else if(keyFlag&&position!=2){
//                sendData("2:3\n");//KeyOpt结束
//                keyFlag=false;
//            }
            return mFragmentList.get(position);
        }

        @Override
        public int getCount() {
            return 4;
        }

        @Override
        public CharSequence getPageTitle(int position) {
            switch (position) {
                case 0:
                    return "走迷宫";
                case 1:
                    return "手柄操作";
                case 2:
                    return "语音控制";
                case 3:
                    return "路径控制";
            }
            return null;
        }
    }
}
