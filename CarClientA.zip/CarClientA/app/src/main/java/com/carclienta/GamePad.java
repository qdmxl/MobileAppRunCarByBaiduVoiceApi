package com.carclienta;

 


import android.content.Context;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Matrix;
import android.graphics.Paint;
import android.support.annotation.Nullable;
import android.util.AttributeSet;
import android.util.DisplayMetrics;
import android.view.KeyEvent;
import android.view.MotionEvent;
import android.view.SurfaceHolder;
import android.view.SurfaceHolder.Callback;
import android.view.SurfaceView;
import android.view.View;
import android.view.ViewTreeObserver;

import java.io.IOException;

/**
 * 
 * @author Himi
 *
 */
public class GamePad extends View {
	private Paint paint;
	//private Canvas canvas;
	//private int screenW, screenH;
	Rocker rocker;
	private OnDirectionListener mOnDirectionListener;   //移动方向监听器
	public void setOnDirectionListener(OnDirectionListener onDirectionListener) {
		this.mOnDirectionListener = onDirectionListener;
	}

	public interface OnDirectionListener {
		void onUp();
		void onUpLeft();
		void onLeft();
		void onDownLeft();
		void onDown();
		void onDownRight();
		void onRight();
		void onUpRight();
		void onLeave();
	}


	public GamePad(Context context) {
		super(context);
	}

	public GamePad(Context context, @Nullable AttributeSet attrs) {
		super(context, attrs);
		paint = new Paint();
		paint.setColor(Color.RED);
		paint.setAntiAlias(true);
		setFocusable(true);

		DisplayMetrics dm = new DisplayMetrics();
		dm = getResources().getDisplayMetrics();
		float density = dm.density; // 屏幕密度（像素比例：0.75/1.0/1.5/2.0）
		int densityDPI = dm.densityDpi; // 屏幕密度（每寸像素：120/160/240/320）
		float xdpi = dm.xdpi;
		float ydpi = dm.ydpi;
		int screenWidth = dm.widthPixels; // 屏幕宽（像素，如：480px）
		int screenHeight = dm.heightPixels; // 屏幕高（像素，如：800px）

		rocker = new Rocker(screenWidth,screenHeight,screenWidth/4);

	}

	@Override
	protected void onMeasure(int widthMeasureSpec, int heightMeasureSpec) {
		super.onMeasure(widthMeasureSpec, heightMeasureSpec);
	}

	@Override
	protected void onDraw(Canvas canvas) {
		//super.onDraw(canvas);
		rocker.draw(canvas);
	}

	/**
	 * 触屏事件监听
	 */
	@Override
	public boolean onTouchEvent(MotionEvent event) {
		//当用户手指抬起，应该恢复小圆到初始位置
		if (event.getAction() == MotionEvent.ACTION_UP) {
			rocker.reset();
			mOnDirectionListener.onLeave();
		} else{
			int pointX = (int) event.getX();
			int pointY = (int) event.getY();
			if(event.getAction() == MotionEvent.ACTION_DOWN){ 
				rocker.begin(pointX,pointY);
			}else if(event.getAction() == MotionEvent.ACTION_MOVE){  
				rocker.update(pointX,pointY);
			}
			int dir=(int)((rocker.degreesByNormalSystem+22.5)/45);
			switch (dir){
				case 0:mOnDirectionListener.onLeft();break;
				case 1:mOnDirectionListener.onUpLeft();break;
				case 2:mOnDirectionListener.onUp();break;
				case 3:mOnDirectionListener.onUpRight();break;
				case 4:mOnDirectionListener.onRight();break;
				case 5:mOnDirectionListener.onDownRight();break;
				case 6:mOnDirectionListener.onDown();break;
				case 7:mOnDirectionListener.onDownLeft();break;
				default:break;
			}
		}
		invalidate();
		return true;
	} 

	/**
	 * 按键事件监听
	 */
	@Override
	public boolean onKeyDown(int keyCode, KeyEvent event) {
		return super.onKeyDown(keyCode, event);
	} 

}
