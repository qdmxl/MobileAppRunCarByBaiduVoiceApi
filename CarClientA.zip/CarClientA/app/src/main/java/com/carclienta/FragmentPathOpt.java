package com.carclienta;

import android.content.pm.PackageInfo;
import android.graphics.Bitmap;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.os.Bundle;
import android.support.v4.app.Fragment;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.MotionEvent;
import android.view.View;
import android.view.ViewGroup;
import android.view.ext.SatelliteMenu;
import android.view.ext.SatelliteMenuItem;
import android.widget.ImageView;
import android.widget.Toast;

import java.io.OutputStream;
import java.net.Socket;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.concurrent.ExecutorService;


public class FragmentPathOpt extends Fragment {
    private View view;
    private ImageView iv_canvas;
    private Bitmap baseBitmap;
    private Canvas canvas;
    private Paint paint;
    private Paint paint2;
    private Paint paint3;
    private List<point> lp=new ArrayList<>();
    private List<point> lp2=null;
    public int num;
    private Path path=new Path(0.5);

    // 输出流对象
    OutputStream outputStream;
    Socket socket;
    ExecutorService mThreadPool;
    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        view=inflater.inflate(R.layout.fragment_pathopt, container, false);
        initView();
        return view;
    }

    @Override
    public void onViewCreated(View view, Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);
    }

    private void initView() {
        SatelliteMenu menu = (SatelliteMenu) view.findViewById(R.id.menu);
        List<SatelliteMenuItem> items = new ArrayList<SatelliteMenuItem>();
        items.add(new SatelliteMenuItem(4, R.drawable.ic_4));
        items.add(new SatelliteMenuItem(3, R.drawable.ic_3));
        items.add(new SatelliteMenuItem(2, R.drawable.ic_2));
        items.add(new SatelliteMenuItem(1, R.drawable.ic_1));
        menu.addItems(items);

        menu.setOnItemClickedListener(new SatelliteMenu.SateliteClickedListener() {

            public void eventOccured(int id) {
                String str;
                Log.i("sat", "Clicked on " + id);
                switch (id){
                    case 1:
                        lp.clear();
                        num=0;
                        baseBitmap = Bitmap.createBitmap(iv_canvas.getWidth(),
                                iv_canvas.getHeight(), Bitmap.Config.ARGB_8888);
                        canvas = new Canvas(baseBitmap);
                        canvas.drawColor(Color.WHITE);
                        iv_canvas.setImageBitmap(baseBitmap);
                        break;
                    case 2:
                        lp2=copyListP(lp);
                        str=path.prasePath(lp2);
                        lp2.clear();
                        if(str==null)
                        {
                            Toast.makeText(getActivity(),"请输入至少2点的路径",Toast.LENGTH_SHORT).show();
                            return;
                        }
                        System.out.println(str);
                        sendData(str);
                        break;
                    case 3:
                        str="4:2\n";
                        sendData(str);
                        break;
                    case 4:
                        str="4:3\n";
                        sendData(str);
                        break;
                }
            }
        });

        iv_canvas=view.findViewById(R.id.iv_canvas);
        paint = new Paint();
        paint.setAntiAlias(true);//抗锯齿
        paint.setStyle(Paint.Style.STROKE);
        paint.setColor(Color.argb(200,51,153,255));
        paint2 =new Paint();
        paint2.setTextSize(25);
        paint2.setColor(Color.RED);
        paint3 =new Paint();
        paint3.setStrokeWidth(5);
        paint3.setColor(Color.GREEN);
        iv_canvas.setOnTouchListener(touch);
    }

    List<point> copyListP(List<point> lp){
        List<point> lp2 = new ArrayList<>();
        int i=0;
        while (i<lp.size()){
            lp2.add(new point(lp.get(i).x,lp.get(i++).y));
        }
        return lp2;
    }

    static class point{
        public float x;
        public float y;

        public point(float x, float y) {
            this.x = x;
            this.y = y;
        }

        public void setVal(float x,float y){
            this.x=x;
            this.y=y;
        }
    }

    private View.OnTouchListener touch=new View.OnTouchListener() {
        // 定义手指开始触摸的坐标
        float startX;
        float startY;
        @Override
        public boolean onTouch(View v, MotionEvent event) {
            switch (event.getAction()) {
                // 用户按下动作
                case MotionEvent.ACTION_DOWN:
                    // 第一次绘图初始化内存图片，指定背景为白色
                    if (baseBitmap == null) {
                        baseBitmap = Bitmap.createBitmap(iv_canvas.getWidth(),
                                iv_canvas.getHeight(), Bitmap.Config.ARGB_8888);
                        canvas = new Canvas(baseBitmap);
                        canvas.drawColor(Color.WHITE);
                    }
                    startX = event.getX();
                    startY = event.getY();
                    canvas.drawCircle(startX,startY,30,paint);
                    num++;
                    canvas.drawText(String.valueOf(num),startX,startY,paint2);
                    lp.add(new point(startX,startY));
                    if(lp.size()>=2){
                        point perp=lp.get(lp.size()-2);
                        canvas.drawLine(perp.x,perp.y,startX,startY,paint3);
                    }
                    // 把图片展示到ImageView中
                    iv_canvas.setImageBitmap(baseBitmap);
                    break;
                // 用户手指在屏幕上移动的动作
                case MotionEvent.ACTION_MOVE:
                    break;
                case MotionEvent.ACTION_UP:
                    break;
                default:
                    break;
            }
            return true;
        }
    };

    void sendData(final String str){
        socket=((MainActivity)getActivity()).getSocket();
        mThreadPool=((MainActivity)getActivity()).getmThreadPool();
        mThreadPool.execute(new Runnable() {
            @Override
            public void run() {
                try {
                    // 步骤1：从Socket 获得输出流对象OutputStream
                    // 该对象作用：发送数据
                    outputStream = socket.getOutputStream();

                    // 步骤2：写入需要发送的数据到输出流对象中
                    outputStream.write(str.getBytes("utf-8"));
                    // 特别注意：数据的结尾加上换行符才可让服务器端的readline()停止阻塞

                    // 步骤3：发送数据到服务端
                    outputStream.flush();
                } catch (Exception e) {
                    e.printStackTrace();
                }
            }
        });
    }
}
