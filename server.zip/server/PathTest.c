#include "Path.h"

void main(){
	char str[100]="1=20,3=90,1=30,7=90,5=40";
	path* pt=createPath();
	prasePathStr(str,pt);
	printfPath(pt,0);
	printf("%s\n",str);
	getchar();
}