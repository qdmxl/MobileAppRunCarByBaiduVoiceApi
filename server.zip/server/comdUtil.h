#include <stdio.h>

#include<stdlib.h>
#include <string.h>

//服务器若用readline来读取。客户端发送结束要有\n。
//不过这个没用readline，但是comdUtil.c有处理。
//命令格式
//"1:1:0.8,30,5,10,10,7.0\n"
//"1:2\n"
//"1:3\n"
//"maze:conf:0.8,30,5,10,10,7.0"
//"maze:start"
//"maze:end"

//"keyopt:start"
//"keyopt:opt:0-8" 0:停止 1:前进 2:前进左转 3:左转 4:后退左转 ...
//"keyopt:end"

//"soundopt:start"
//"soundopt:opt:0-8"
//"soundopt:end"

//"pathopt:conf:路径链表"
//"pathopt:start"
//"pathopt:end"
//路径链表 1=20,3=90,1=30,7=90,5=40
//1,3,5,7 前左后右
//1,5=距离
//5,7=角度

typedef enum comdType{
	MAZE=1,
	KEYOPT,
	SOUNDOPT,
	PATHOPT
}cType;

typedef enum comdSubType{
	CONF=1,
	START,
	END,
	OPT
}csType;

typedef struct Comd{
	cType ct;
	csType cst;
	union{
		char* conf;
		int opt;
	}parm;
}comd;

void printfComd(comd* cd);
int praseComd(char* str,comd* cd);
