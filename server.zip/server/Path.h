#include <stdio.h>

#include<stdlib.h>
#include <string.h>

#define PATHMAX 100

typedef enum Direction{
	RUN=1,
	LEFT=3,
	BACK=5,
	RIGHT=7
}Dir;

typedef struct Node{
	Dir dir;
	int val;
	struct Node* next;
	struct Node* pre;
}node;

typedef struct Path{
	node* head;
	node* tail;
	int num;
}path;

path* createPath();
int delPath(path* pt);
node* createNode();
int addNode(path* pt,node* nd,int positiveSeq);
node* getNode(path* pt,int positiveSeq);
int empty(path* pt);

void printfPath(path* pt,int positiveSeq);
int prasePathStr(char* str,path* pt,int positiveSeq);