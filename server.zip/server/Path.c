#include "Path.h"

path* createPath(){
	path* pt=(path*)malloc(sizeof(path));
	pt->head=pt->tail=NULL;
	pt->num=0;
	return pt;
}

int delPath(path* pt){
	if(!pt)
		return 0;
	
	node* nd;
	while(pt->tail){
		if(pt->num==1)
		{
			free(pt->tail);
			pt->tail=pt->head=NULL;
			pt->num=0;
			break;
		}else if(pt->num>1){
			nd=pt->tail;
			pt->tail=pt->tail->pre;
			free(nd);
			pt->num--;
		}
	}
	if(pt->num==0)
		free(pt);
	return 1;
}

node* createNode(){
	node* nd=(node*)malloc(sizeof(node));
	nd->dir=0;
	nd->val=0;
	nd->next=nd->pre=NULL;
	return nd;
}

int addNode(path* pt,node* nd,int positiveSeq){
	if(!pt||!nd)
		return 0;
	
	if(pt->head==NULL){
		pt->head=pt->tail=nd;
		nd->next=nd->pre=NULL;
		pt->num++;
		return 1;
	}
	if(positiveSeq==1){
		pt->tail->next=nd;
		nd->pre=pt->tail;
		pt->tail=nd;
	}else if(positiveSeq==0){
		pt->head->pre=nd;
		nd->next=pt->head;
		pt->head=nd;
	}
	pt->num++;
	return 1;
}

node* getNode(path* pt,int positiveSeq){
	node* nd=NULL;
	if(!pt||pt->head==NULL)
		return NULL;
	if(pt->num==1)
	{
		nd=pt->head;
		pt->head=pt->tail=NULL;
		pt->num=0;
		return nd;
	}
	if(positiveSeq==1){
		pt->tail=pt->tail->pre;
		nd=pt->tail->next;
		nd->pre=NULL;
		pt->tail->next=NULL;
	}else if(positiveSeq==0){
		pt->head=pt->head->next;
		nd=pt->head->pre;
		nd->next=NULL;
		pt->head->pre=NULL;
	}
	pt->num--;
	return nd;
}

int empty(path* pt){
	if(pt->num==0&&pt->head==NULL)
		return 1;
	else
		return 0;
}

void printfPath(path* pt,int positiveSeq)
{
	node* nd=NULL;
	nd=getNode(pt,positiveSeq);
	while(nd){
		printf("num:%d,%d=%d\n",pt->num,nd->dir,nd->val);
		free(nd);
		nd=getNode(pt,positiveSeq);
	}
	free(pt);
}

//路径链表 1=20,3=90,1=30,7=90,5=40
//1,3,5,7 前左后右
//1,5=距离 cm
//5,7=角度 °
int prasePathStr(char* str,path* pt,int positiveSeq){
	if(!str||!pt)
		return 0;
	char* stp[PATHMAX];
	int i=0;
	char* delim=",";//分隔符字符串
	char* delim2="=";	
	for(;i<PATHMAX;i++)
		stp[i]=NULL;
	i=0;
    char* p=strtok(str,delim);//第一次调用strtok
    while(p!=NULL){//当返回值不为NULL时，继续循环
        //printf("%s\n",p);//输出分解的字符串
		//printf("sizeof=%d\n",sizeof(p)/sizeof(p[0])); p使用了同一段内存，所以多次分解使用sizeof测量大小相同
		//printf("strlen=%d\n",strlen(p));
		stp[i]=(char*)malloc(strlen(p));
		strcpy(stp[i],p);
		i++;
        p=strtok(NULL,delim);//继续调用strtok，分解剩下的字符串
    }
	node* nd;
	i=0;
	while(stp[i]){
		nd=createNode();
		nd->dir=(Dir)atoi(strtok(stp[i],delim2));
		nd->val=atoi(strtok(NULL,delim2));
		//printf("nd->dir=%d=nd->val=%d\n",nd->dir,nd->val);
		addNode(pt,nd,positiveSeq);
		free(stp[i]);
		i++;
	}
	return 1;
}