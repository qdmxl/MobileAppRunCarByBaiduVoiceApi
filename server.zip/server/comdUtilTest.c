#include "comdUtil.h"

void main(){
	char str[50]="1:1:0,0.5,50,30,30,30,15";
	comd* cd=(comd*)malloc(sizeof(comd));
	praseComd(str,cd);
	printfComd(cd);
	getchar();
}