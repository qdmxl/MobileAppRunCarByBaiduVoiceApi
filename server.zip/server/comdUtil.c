#include "comdUtil.h"

void printfComd(comd* cd){
	switch(cd->ct){
		case MAZE:printf("MAZE:");break;
		case KEYOPT:printf("KEYOPT:");break;
		case SOUNDOPT:printf("SOUNDOPT:");break;
		case PATHOPT:printf("PATHOPT:");break;
		default:break;
	}
	switch(cd->cst){
		case CONF:printf("CONF:%s\n",cd->parm.conf);break;
		case START:printf("START\n");break;
		case END:printf("END\n");break;
		case OPT:printf("OPT:%d\n",cd->parm.opt);break;
		default:break;
	}
}

int praseComd(char* str,comd* cd){
	if(!str)
		return 0;
	unsigned int no=0;
	char* delim=":";//分隔符字符串
    char* p=strtok(str,delim);//第一次调用strtok
    while(p!=NULL){//当返回值不为NULL时，继续循环
        //printf("%s\n",p);//输出分解的字符串
		switch(no){
			case 0:cd->ct=(cType)atoi(p);break;
			case 1:cd->cst=(csType)atoi(p);break;
			case 2:
				if(cd->cst==CONF)
				{
					//int i=0;
					int len=strlen(p);
					//int len=sizeof(p)/sizeof(p[0]);
					//for(;i<len;i++)
					//{
					//	printf("%d:%c\n",i,p[i]);
					//}
					//if(p[len-2]=='\n')
					//{
					//	p[len-2]='\0';
					//	len=len-1;
					//}
					char* temp=(char*)malloc(len);
					strcpy(temp,p);
					cd->parm.conf=temp;
				}else if(cd->cst==OPT)
					cd->parm.opt=atoi(p);
				break;
			default:break;
		}
        p=strtok(NULL,delim);//继续调用strtok，分解剩下的字符串
		no++;
    }
	if(no==2)
		cd->parm.opt=0;
	return 1;
}