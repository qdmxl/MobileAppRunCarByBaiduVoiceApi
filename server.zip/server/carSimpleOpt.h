#include <stdio.h>
#include <stdlib.h>
#include <softPwm.h>
#include <time.h>
#include <wiringPi.h>

#include "Debug.h"

#define Trig  28//前超声波
#define Echo  29
#define Trig1 24//左超声波
#define Echo1 25
#define Trig2 21//右超声波
#define Echo2 22

#define SPEEDSCALE 0.8	//最高速的比例0-1
#define TRUNSCALE 0.1	//偏转时左右轮速度比
#define ANGLEPERMT 800/90 //偏转每度所需毫秒值

void carInit(){
	wiringPiSetup();
	pinMode(Echo, INPUT);
    pinMode(Trig, OUTPUT);
	pinMode(Echo1, INPUT);
    pinMode(Trig1, OUTPUT);
	pinMode(Echo2, INPUT);
    pinMode(Trig2, OUTPUT);
    /*WiringPi GPIO*/
    pinMode(1, OUTPUT);  //IN1
    pinMode(4, OUTPUT);  //IN2
    pinMode(5, OUTPUT);  //IN3
    pinMode(6, OUTPUT);  //IN4
    softPwmCreate(1, 1, 100);
    softPwmCreate(4, 1, 100);
    softPwmCreate(5, 1, 100);
    softPwmCreate(6, 1, 100);
}
	
//返回距离 单位cm
float disMeasure(int trig,int echo)
{
	//struct timeval {
	//	time_t tv_sec;	//64位系统下的time_t类型即long类型长度为8个字节
	//	suseconds_t tv_usec;
	//;
    struct timeval tv1;
	struct timeval tv2;
    long start, stop;
    float dis;
    digitalWrite(trig, LOW);
    delayMicroseconds(2);
    digitalWrite(trig, HIGH);
    delayMicroseconds(10); //发出超声波脉冲
    digitalWrite(trig, LOW);
    while(!(digitalRead(echo) == 1));
    gettimeofday(&tv1, NULL); //获取当前时间
    while(!(digitalRead(echo) == 0));
    gettimeofday(&tv2, NULL); //获取当前时间
    start = tv1.tv_sec * 1000000 + tv1.tv_usec; //微秒级的时间 
    stop = tv2.tv_sec * 1000000 + tv2.tv_usec;
    dis = (float)(stop - start) / 1000000 * 34000 / 2; //求出距离
    return dis;
}

void brake(int time) //刹车，停车 time ms
{
    softPwmWrite(1, 0);
    softPwmWrite(4, 0);
    softPwmWrite(5, 0);
    softPwmWrite(6, 0);
    delay(time);//执行时间，可以调整
}


void run() // 前进
{
    softPwmWrite(4, 0);
    softPwmWrite(1, 100*SPEEDSCALE); //左轮前进
    softPwmWrite(6, 0);
    softPwmWrite(5, 100*SPEEDSCALE); //右轮前进
}


//length	cm
//curSpeed	cm/s 为正值
void runLength(float length){
	float tempSpeed=SPEEDSCALE*50;
	float endTime=0;
	float frontDis=0;
	
	endTime=length*1000/tempSpeed+millis();//millis() wiringPiSetup开始后的ms

	while(1){
		run();
		delay(50);
		if(millis()>=endTime){
			brake(10);
			break;
		}
			
	}
}

void left(int time) //前进左转(左轮慢进，右轮前进)
{
    softPwmWrite(1, 100*TRUNSCALE*SPEEDSCALE);//左轮慢前进
    softPwmWrite(4, 0);
    softPwmWrite(5, 100*SPEEDSCALE);//右轮前进
    softPwmWrite(6, 0); 
    delay(time);
}

void left2(int time) //左转(左轮后退，右轮前进)
{
    softPwmWrite(1, 0);
    softPwmWrite(4, 100*SPEEDSCALE);
    softPwmWrite(5, 100*SPEEDSCALE);//右轮前进
    softPwmWrite(6, 0); 
    delay(time);
}

void leftAngle(unsigned char angle){
	int angleToTime = (int)ANGLEPERMT*angle;
	left2(angleToTime);
	brake(10);
}

void right(int time) //右转(右轮慢进，左轮前进)
{
    softPwmWrite(1, 100*SPEEDSCALE);//左轮前进
    softPwmWrite(4, 0); 
    softPwmWrite(5, 100*TRUNSCALE*SPEEDSCALE);//左轮慢前进
    softPwmWrite(6, 0);
    delay(time); //执行时间，可以调整
}

void right2(int time) //右转(右轮后退，左轮前进)
{
    softPwmWrite(1, 100*SPEEDSCALE);//左轮前进
    softPwmWrite(4, 0); 
    softPwmWrite(5, 0);
    softPwmWrite(6, 100*SPEEDSCALE);
    delay(time); //执行时间，可以调整
}


void rightAngle(unsigned char angle){
	int angleToTime = (int)ANGLEPERMT*angle;
	right2(angleToTime);
	brake(10);
}

void back(int time) //后退
{
    softPwmWrite(4, 100*SPEEDSCALE); //左轮back
    softPwmWrite(1, 0);
    softPwmWrite(6, 100*SPEEDSCALE); //右轮back
    softPwmWrite(5, 0);
    delay(time); //执行时间，可以调整
}

//length	cm
//curSpeed	cm/s 为负值
float backLength(float length){
	unsigned int startTime=millis();
	float startDis=disMeasure(Trig,Echo);
	float Dis=0;
	while(1){
		back(100);
		Dis=disMeasure(Trig,Echo);
		if(Dis-startDis>=length)
		{
			back(20);
			return (float)(Dis-startDis)*1000/(millis()-startTime);
		}
	}
}

void backLeft(int time) //后退左转(左轮慢后退，右轮后退)
{
    softPwmWrite(1, 0);
    softPwmWrite(4, 100*TRUNSCALE*SPEEDSCALE);
    softPwmWrite(5, 0);
    softPwmWrite(6, 100*SPEEDSCALE); 
    delay(time);
}

void backRight(int time) //后退右转(右轮慢后退，左轮后退)
{
    softPwmWrite(1, 0);
    softPwmWrite(4, 100*SPEEDSCALE); 
    softPwmWrite(5, 0);
    softPwmWrite(6, 100*TRUNSCALE*SPEEDSCALE);
    delay(time); //执行时间，可以调整
}
