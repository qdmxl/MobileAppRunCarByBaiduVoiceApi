#include <stdio.h>
#include <stdlib.h>

#include <unistd.h>
#include <sys/types.h>
#include <sys/socket.h>
#include <strings.h>
#include <string.h>
#include <ctype.h>
#include <arpa/inet.h>

#include <sys/stat.h>
#include <fcntl.h>

#include <sys/wait.h>
#include <errno.h>

#include <pthread.h>

#include "wrap.h"
#include "comdUtil.h"
#include "Debug.h"
#include "carSimpleOpt.h"
#include "Path.h"

#define SERV_PORT 6666

void dowork(char* buf,int len);
void doMazeWork(comd* cd);
void doKeyoptWork(comd* cd);
void doSoundoptWork(comd* cd);
void doPathoptWork(comd* cd);
void* pathoptTask(void* arg);

int main(void)
{
    int sfd, cfd;
    int len,ret;
    char buf[BUFSIZ], clie_IP[BUFSIZ];

    struct sockaddr_in serv_addr, clie_addr;
    socklen_t clie_addr_len;
	
	int count=0;

	carInit();
	
	/*创建一个socket 指定IPv4协议族 TCP协议*/
    sfd = Socket(AF_INET, SOCK_STREAM, 0);

    bzero(&serv_addr, sizeof(serv_addr));           //将整个结构体清零
    serv_addr.sin_family = AF_INET;                 //选择协议族为IPv4
    serv_addr.sin_addr.s_addr = htonl(INADDR_ANY);  //监听本地所有IP地址
    serv_addr.sin_port = htons(SERV_PORT);          //绑定端口号    

	/*绑定服务器地址结构*/
    ret=Bind(sfd, (struct sockaddr *)&serv_addr, sizeof(serv_addr));
	
	/*设定链接上限,注意此处不阻塞*/
    ret=Listen(sfd, 2);                                
    printf("wait for client connect ...\n");

	/*获取客户端地址结构大小*/ 
    clie_addr_len = sizeof(clie_addr_len);
	
	/*参数1是sfd; 参2传出参数, 参3传入传出参数, 全部是client端的参数*/
	cfd = Accept(sfd, (struct sockaddr *)&clie_addr, &clie_addr_len);
	printf("cfd = ----%d\n", cfd);
	inet_ntop(AF_INET, &clie_addr.sin_addr.s_addr, clie_IP, sizeof(clie_IP));
	printf("client IP: %s  port:%d\n", clie_IP, ntohs(clie_addr.sin_port));
    while (1) {
		/*读取客户端发送数据*/
		len = Read(cfd, buf, sizeof(buf));
		if(len==0)
			count++;
		else if(len>0){
			//PLOG("len:%d\n",len);
			Write(STDOUT_FILENO, buf, len);

			/*处理客户端数据*/
			dowork(buf,len);
			/*处理完数据回写给客户端*/
			//Write(cfd, buf, len); 
		}
		if(count>0xff||len<0)
		{
			count=0;
			Close(cfd);
			cfd = Accept(sfd, (struct sockaddr *)&clie_addr, &clie_addr_len);
			printf("cfd = ----%d\n", cfd);
			inet_ntop(AF_INET, &clie_addr.sin_addr.s_addr, clie_IP, sizeof(clie_IP));
			printf("client IP: %s  port:%d\n", clie_IP, ntohs(clie_addr.sin_port));
		}
    }
	 /*关闭链接*/
    Close(sfd);
	Close(cfd);
 

    return 0;
}

comd* cdPre=NULL;
comd* cd=NULL;
void dowork(char* buf,int len){
	cd=(comd*)malloc(sizeof(comd));
	if(!praseComd(buf,cd))
		return;
	if(cdPre){
		if(cdPre->ct != cd->ct && cdPre->cst != END)//上一类操作还未结束，又开始了下一类操作,按键操作除外
		{
			if(cdPre->ct!=KEYOPT){
				cd->ct=cdPre->ct;
				cd->cst=END;
				cd->parm.opt=0;
			}
		}
	}
	switch(cd->ct){
		case MAZE:	  doMazeWork(cd);break;
		case KEYOPT:  doKeyoptWork(cd);break;
		case SOUNDOPT:doSoundoptWork(cd);break;
		case PATHOPT: doPathoptWork(cd);break;
		default:break;
	}
	if(cdPre)
		free(cdPre);
	cdPre=cd;
}


char saveMazeConf[50];
pid_t child;
//"maze:conf:0.8,30,5,10,10,7.0"
//"maze:start"
//"maze:end"
void doMazeWork(comd* cd){
	switch(cd->cst){
		case CONF:
			PLOG("doMazeWork CONF:%s\n",cd->parm.conf);
			strcpy(saveMazeConf,cd->parm.conf);
			break;
		case START:
			PLOG("doMazeWork START\n");
			if((child=fork())==-1)
			{
				printf("Fork Error : %s\n", strerror(errno));
				exit(1);
			}
			else 
				if(child==0) // 子进程
				{
					/*调用execl函数，用可执行程序file_creat替换本进程*/
					if(execl("./maze","maze",saveMazeConf,NULL)<0)
						perror("execl error!");
					else
						PLOG("start maze\n");
				}
			break;
		case END:
			PLOG("doMazeWork END\n");
			if(kill(child,9)==0)
				PLOG("kill ok\n");
			break;
		case OPT:
			break;
		default:break;
	}	
}

//"keyopt:start" //不做控制
//"keyopt:opt:0-8" 0:停止 1:前进 2:前进左转 3:左转 4:后退左转 ...
//"keyopt:end"	//不做控制
void doKeyoptWork(comd* cd){
	switch(cd->cst){
		case CONF:break;
		case START:PLOG("doKeyoptWork START\n");break;
		case END:PLOG("doKeyoptWork END\n");break;
		case OPT:
			PLOG("doKeyoptWork OPT:%d\n",cd->parm.opt);
			switch(cd->parm.opt){
				case 0:brake(20);			break;
				case 1:run();delay(20);		break;
				case 2:left(20);			break;
				case 3:left2(20);			break;
				case 4:backLeft(20);		break;
				case 5:back(20);			break;
				case 6:backRight(20);		break;
				case 7:right2(20);			break;
				case 8:right(20);			break;
				default:break;
			}
			break;
		default:break;
	}
}

//"soundopt:start"
//"soundopt:opt:0-8"
//"soundopt:end"
void doSoundoptWork(comd* cd){
	switch(cd->cst){
		case CONF:break;
		case START:PLOG("doSoundoptWork START\n");break;
		case END:PLOG("doSoundoptWork END\n");break;
		case OPT:
			PLOG("doSoundoptWork OPT:%d\n",cd->parm.opt);
			switch(cd->parm.opt){
				case 0:brake(20);		break;
				case 1:run();delay(20);	break;
				case 2:left(20);		break;
				case 3:left2(20);		break;
				case 4:backLeft(20);	break;
				case 5:back(20);		break;
				case 6:backRight(20);	break;
				case 7:right2(20);		break;
				case 8:right(20);		break;
				default:break;
			}
			break;
		default:break;
	}
}

char savePathStr[1024];
path* pt;
unsigned char pflag=0;
pthread_t tid;
//"pathopt:conf:路径链表"
//"pathopt:start"
//"pathopt:end"
//路径链表 1=20,3=90,1=30,7=90
//1,3,7 前左右
//1=距离 cm
//3,7=角度 °
void doPathoptWork(comd* cd){
	switch(cd->cst){
		case CONF:
			PLOG("doPathoptWork CONF\n");
			delPath(pt);
			pt=createPath();
			strcpy(savePathStr,cd->parm.conf);
			if(prasePathStr(savePathStr,pt,1));
				PLOG("prasePathStr OK\n");
			break;
		case START:
			PLOG("doPathoptWork START\n");
			if(pflag==0){
				int ret=pthread_create(&tid,NULL,pathoptTask,NULL);
				if(ret!=0)
				{
					fprintf(stderr,"pthread_create error:%s\n",strerror(ret));
				}
				pflag=1;
			}else
				printf("The road is not finished yet.\n");
			break;
		case END:
			PLOG("doPathoptWork END\n");
			if(pflag==1)//提前终止
			{
				pthread_cancel(tid);
				brake(20);
			}
			pflag=0;
			break;
		case OPT:break;
		default:break;
	}
}

void *pathoptTask(void* arg)
{
	pthread_setcancelstate(PTHREAD_CANCEL_ENABLE, NULL); 
	/*同步取消，等到下一个取消点再取消*/ 
	//pthread_setcanceltype(PTHREAD_CANCEL_DEFERRED, NULL);  要和这个配合使用pthread_testcancel();
	/*异步取消， 线程接到取消信号后，立即退出*/ 
	pthread_setcanceltype(PTHREAD_CANCEL_ASYNCHRONOUS, NULL);
	node* nd=getNode(pt,0);
	node temp={
		nd->dir,
		nd->val
	};
	free(nd);
	printf("dir=val:%d=%d\n",temp.dir,temp.val);
	while(temp.dir!=BACK){
		float speed;
		switch(temp.dir){
			case RUN:  
				//speed=runLength(temp.val);
				runLength(temp.val);
				//PLOG("pathoptTask:run speed=%.2f\n",speed);
				break;
			case LEFT: 
				leftAngle(temp.val);
				break;
			case BACK: //已无效
				speed=backLength(temp.val);
				PLOG("pathoptTask:back speed=%.2f\n",speed);
				break;
			case RIGHT:
				rightAngle(temp.val);
				break;
			default:break;
		}
		nd=getNode(pt,0);
		if(nd){
			temp.dir=nd->dir;
			temp.val=nd->val;
			free(nd);
		}else{
			temp.dir=BACK;
			temp.val=0;
		}
		printf("dir=val:%d=%d\n",temp.dir,temp.val);
	}
	pflag=0;
	free(pt);
	pt=NULL;
	return (void*)0;
}


